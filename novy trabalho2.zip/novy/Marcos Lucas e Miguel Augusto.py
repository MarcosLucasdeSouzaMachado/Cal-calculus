import os
import re
from pathlib import Path


class MIPSPipelineSimulator:
    """Simula pipeline de 5 estágios MIPS com adiantamento de dados"""

    REGISTERS = {
        '$zero': 0, '$at': 1, '$v0': 2, '$v1': 3,
        '$a0': 4, '$a1': 5, '$a2': 6, '$a3': 7,
        '$t0': 8, '$t1': 9, '$t2': 10, '$t3': 11, '$t4': 12, '$t5': 13, '$t6': 14, '$t7': 15,
        '$s0': 16, '$s1': 17, '$s2': 18, '$s3': 19, '$s4': 20, '$s5': 21, '$s6': 22, '$s7': 23,
        '$t8': 24, '$t9': 25,
        '$k0': 26, '$k1': 27,
        '$gp': 28, '$sp': 29, '$fp': 30, '$ra': 31
    }

    INSTRUCTION_TYPES = {
        'add': ('R', 1), 'sub': ('R', 1), 'and': ('R', 1), 'or': ('R', 1),
        'xor': ('R', 1), 'slt': ('R', 1),
        'sll': ('R', 1), 'srl': ('R', 1), 'sra': ('R', 1),
        'mult': ('R', 3), 'div': ('R', 3),
        'mfhi': ('R', 3), 'mflo': ('R', 3),

        'addi': ('I', 1), 'andi': ('I', 1), 'ori': ('I', 1), 'xori': ('I', 1),
        'slti': ('I', 1),

        'lw': ('LOAD', 2),
        'sw': ('STORE', 0),

        'beq': ('BRANCH', 0), 'bne': ('BRANCH', 0),

        'j': ('JUMP', 0), 'jal': ('JUMP', 0),
    }

    def get_register_number(self, reg):
        """Converte nome do registrador para número"""
        reg = reg.strip().lower()
        if reg in self.REGISTERS:
            return self.REGISTERS[reg]
        raise ValueError(f"Registrador inválido: {reg}")

    def parse_memory_operand(self, operand):
        """Parse operand como 'offset($register)'"""
        match = re.match(r'(-?\d+)\s*\(\s*(\$\w+)\s*\)', operand.strip())
        if match:
            offset = int(match.group(1))
            register = self.get_register_number(match.group(2))
            return offset, register
        raise ValueError(f"Formato de memória inválido: {operand}")

    def parse_instruction(self, instruction_str):
        """Parse uma instrução MIPS"""
        instruction_str = instruction_str.strip().upper()

        if '#' in instruction_str:
            instruction_str = instruction_str[:instruction_str.index('#')].strip()

        if not instruction_str:
            return None

        parts = instruction_str.split()
        opcode = parts[0].lower()

        if opcode not in self.INSTRUCTION_TYPES:
            return None

        inst_type, latency = self.INSTRUCTION_TYPES[opcode]

        try:
            if inst_type == 'R':
                if opcode in ['sll', 'srl', 'sra']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    shamt = int(parts[3])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rt],
                        'reads': [rs]
                    }
                elif opcode in ['mfhi', 'mflo']:
                    rd = self.get_register_number(parts[1].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rd],
                        'reads': []
                    }
                else:
                    rd = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    rt = self.get_register_number(parts[3].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rd],
                        'reads': [rs, rt]
                    }

            elif inst_type in ['I', 'LOAD', 'STORE']:
                if opcode in ['lw', 'sw']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    memory_operand = ' '.join(parts[2:])
                    offset, rs = self.parse_memory_operand(memory_operand)

                    if opcode == 'lw':
                        return {
                            'opcode': opcode,
                            'type': inst_type,
                            'latency': latency,
                            'writes': [rt],
                            'reads': [rs]
                        }
                    else:  # sw
                        return {
                            'opcode': opcode,
                            'type': inst_type,
                            'latency': latency,
                            'writes': [],
                            'reads': [rs, rt]
                        }

                elif opcode in ['beq', 'bne']:
                    rs = self.get_register_number(parts[1].rstrip(','))
                    rt = self.get_register_number(parts[2].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [],
                        'reads': [rs, rt]
                    }

                else:  # addi, andi, ori, xori, slti
                    rt = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    immediate = int(parts[3])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rt],
                        'reads': [rs]
                    }

            elif inst_type == 'JUMP':
                return {
                    'opcode': opcode,
                    'type': inst_type,
                    'latency': latency,
                    'writes': [],
                    'reads': []
                }

        except (IndexError, ValueError):
            return None

        return None

    def simulate_pipeline(self, instructions_str):
        """
        Simula pipeline de 5 estágios MIPS começando do CICLO 0.

        Retorna o número total de ciclos (até quando a última instrução sai de WB).
        """
        lines = instructions_str.strip().split('\n')

        parsed_instructions = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parsed = self.parse_instruction(line)
            if parsed:
                parsed_instructions.append(parsed)

        if not parsed_instructions:
            return 0

        # register_ready_cycle[reg] = ciclo em que valor fica pronto em WB
        register_ready_cycle = {}

        # if_cycle[i] = ciclo em que instrução i entra em IF
        if_cycles = []

        current_if_cycle = 0  # COMEÇA DO CICLO 0

        for inst in parsed_instructions:
            # Verificar dependências
            max_stalls = 0

            for read_reg in inst['reads']:
                if read_reg == 0:
                    continue

                if read_reg in register_ready_cycle:
                    ready_cycle = register_ready_cycle[read_reg]
                    ex_cycle = current_if_cycle + 2

                    if ready_cycle > ex_cycle:
                        stalls_needed = ready_cycle - ex_cycle
                        max_stalls = max(max_stalls, stalls_needed)

            current_if_cycle += max_stalls
            if_cycles.append(current_if_cycle)

            # Calcular quando resultado fica pronto em WB
            # IF (ciclo C) -> ID (C+1) -> EX (C+2) -> MEM (C+3) -> WB (C+4)
            wb_cycle = current_if_cycle + 4

            for write_reg in inst['writes']:
                if write_reg != 0:
                    register_ready_cycle[write_reg] = wb_cycle

            current_if_cycle += 1

        # Última instrução entra em IF em if_cycles[-1]
        # Ela completa WB em if_cycles[-1] + 4
        # Total de ciclos = if_cycles[-1] + 4 + 1 (porque começou do 0)
        last_instruction_wb_cycle = if_cycles[-1] + 4 + 1

        return last_instruction_wb_cycle

    def convert_file(self, input_file, output_file):
        """Converte arquivo MIPS para arquivo com contagem de ciclos"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()

            cycles = self.simulate_pipeline(content)

            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(str(cycles))

            return True
        except Exception as e:
            print(f"Erro ao converter {input_file}: {e}")
            return False


def find_usb_drive():
    """Detecta automaticamente o pendrive"""
    import sys
    if sys.platform == 'win32':
        for drive_letter in range(ord('D'), ord('Z') + 1):
            drive = f"{chr(drive_letter)}:"
            if os.path.exists(drive):
                return drive
    else:
        for mount_point in ['/media', '/mnt']:
            if os.path.exists(mount_point):
                for item in os.listdir(mount_point):
                    path = os.path.join(mount_point, item)
                    if os.path.isdir(path):
                        return path
    return None


def process_mips_files_from_usb(usb_path=None):
    """Processa todos os arquivos TESTE-*.txt no pendrive"""
    simulator = MIPSPipelineSimulator()

    if usb_path is None:
        usb_path = find_usb_drive()
        if usb_path is None:
            print("X Erro: Nenhum pendrive detectado!")
            print("Conecte o pendrive ou especifique o caminho manualmente.")
            return

    if not os.path.exists(usb_path):
        print(f"X Erro: O caminho '{usb_path}' não existe!")
        return

    print(f"Procurando arquivos em: {usb_path}")

    pattern = re.compile(r'TESTE-(\d+)\.txt$', re.IGNORECASE)
    files = []
    for root, dirs, filenames in os.walk(usb_path):
        for file in filenames:
            match = pattern.match(file)
            if match:
                full_path = os.path.join(root, file)
                files.append((int(match.group(1)), full_path, file))

    files.sort()

    if not files:
        print("X Nenhum arquivo TESTE-*.txt encontrado no pendrive!")
        return

    print(f"V Encontrados {len(files)} arquivo(s)\n")

    successful = 0
    failed = 0

    for numero, input_path, input_filename in files:
        input_dir = os.path.dirname(input_path)
        output_filename = f"TESTE-{numero:02d}-RESULTADO.txt"
        output_path = os.path.join(input_dir, output_filename)

        print(f"Processando: {input_filename}")
        print(f"Entrada:  {input_path}")
        print(f"Saída:    {output_path}")

        try:
            if simulator.convert_file(input_path, output_path):
                print(f"V Concluído com sucesso!")
                successful += 1
            else:
                print(f"X Erro ao processar!")
                failed += 1
        except Exception as e:
            print(f"X Erro: {e}")
            failed += 1

        print()


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        usb_path = sys.argv[1]
        print(f"Usando caminho especificado: {usb_path}")
        process_mips_files_from_usb(usb_path)
    else:
        process_mips_files_from_usb()
