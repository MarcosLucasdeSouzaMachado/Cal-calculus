import os
import re
from pathlib import Path

class MIPSPipelineSimulator:
    """Simula pipeline de 5 estágios MIPS com adiantamento de dados"""
    
    # Dicionário de registradores
    REGISTERS = {
        '$zero': 0, '$at': 1, '$v0': 2, '$v1': 3,
        '$a0': 4, '$a1': 5, '$a2': 6, '$a3': 7,
        '$t0': 8, '$t1': 9, '$t2': 10, '$t3': 11, '$t4': 12, '$t5': 13, '$t6': 14, '$t7': 15,
        '$s0': 16, '$s1': 17, '$s2': 18, '$s3': 19, '$s4': 20, '$s5': 21, '$s6': 22, '$s7': 23,
        '$t8': 24, '$t9': 25,
        '$k0': 26, '$k1': 27,
        '$gp': 28, '$sp': 29, '$fp': 30, '$ra': 31
    }
    
    # Tipos de instruções
    INSTRUCTION_TYPES = {
        # R-type (3 ciclos)
        'add': ('R', 1), 'sub': ('R', 1), 'and': ('R', 1), 'or': ('R', 1),
        'xor': ('R', 1), 'slt': ('R', 1), 'mult': ('R', 3), 'div': ('R', 3),
        'mfhi': ('R', 3), 'mflo': ('R', 3),
        'sll': ('R', 1), 'srl': ('R', 1), 'sra': ('R', 1),
        
        # I-type (aritmética)
        'addi': ('I', 1), 'andi': ('I', 1), 'ori': ('I', 1), 'xori': ('I', 1),
        'slti': ('I', 1),
        
        # I-type (memória - 2 ciclos latência)
        'lw': ('LOAD', 2), 'sw': ('STORE', 1),
        
        # I-type (branch - sem latência, resolvido em EX)
        'beq': ('BRANCH', 0), 'bne': ('BRANCH', 0),
        
        # J-type (jump)
        'j': ('JUMP', 0), 'jal': ('JUMP', 0),
    }
    # Rastreio do ciclo em que cada registro foi escrito
    def __init__(self):
        self.instructions = []
        self.register_write_cycle = {}  
        self.current_cycle = 0
    
    def get_register_number(self, reg):
        """Converte nome do registrador para número"""
        reg = reg.strip().lower()
        if reg in self.REGISTERS:
            return self.REGISTERS[reg]
        raise ValueError(f"Registrador inválido: {reg}")
    
    def parse_memory_operand(self, operand):
        """Parse operand como 'offset($register)'"""
        match = re.match(r'(-?\d+)\s*\(\s*(\$\w+)\s*\)', operand.strip())
        if match:
            offset = int(match.group(1))
            register = self.get_register_number(match.group(2))
            return offset, register
        raise ValueError(f"Formato de memória inválido: {operand}")
    
    def parse_instruction(self, instruction_str):
        """Parse uma instrução MIPS"""
        instruction_str = instruction_str.strip().upper()
        
        # Remover comentários
        if '#' in instruction_str:
            instruction_str = instruction_str[:instruction_str.index('#')].strip()
        
        if not instruction_str:
            return None
        
        parts = instruction_str.split()
        opcode = parts[0].lower()
        
        if opcode not in self.INSTRUCTION_TYPES:
            return None
        
        inst_type, latency = self.INSTRUCTION_TYPES[opcode]
        
        try:
            # Parse conforme tipo
            if inst_type == 'R':
                if opcode in ['sll', 'srl', 'sra']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    shamt = int(parts[3])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'rd': rt,
                        'rs': rs,
                        'rt': None,
                        'reads': [rs],
                        'writes': [rt]
                    }
                elif opcode in ['mfhi', 'mflo']:
                    rd = self.get_register_number(parts[1].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'rd': rd,
                        'rs': None,
                        'rt': None,
                        'reads': [],
                        'writes': [rd]
                    }
                else:
                    rd = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    rt = self.get_register_number(parts[3].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'rd': rd,
                        'rs': rs,
                        'rt': rt,
                        'reads': [rs, rt],
                        'writes': [rd]
                    }
            
            elif inst_type in ['I', 'LOAD', 'STORE']:
                if opcode in ['lw', 'sw']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    memory_operand = ' '.join(parts[2:])
                    offset, rs = self.parse_memory_operand(memory_operand)
                    
                    if opcode == 'lw':
                        return {
                            'opcode': opcode,
                            'type': inst_type,
                            'latency': latency,
                            'rd': rt,
                            'rs': rs,
                            'rt': None,
                            'reads': [rs],
                            'writes': [rt]
                        }
                    else:  # sw
                        return {
                            'opcode': opcode,
                            'type': inst_type,
                            'latency': latency,
                            'rd': None,
                            'rs': rs,
                            'rt': rt,
                            'reads': [rs, rt],
                            'writes': []
                        }
                
                elif opcode in ['beq', 'bne']:
                    rs = self.get_register_number(parts[1].rstrip(','))
                    rt = self.get_register_number(parts[2].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'rd': None,
                        'rs': rs,
                        'rt': rt,
                        'reads': [rs, rt],
                        'writes': []
                    }
                
                else:  # addi, andi, ori, xori, slti
                    rt = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    immediate = int(parts[3])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'rd': rt,
                        'rs': rs,
                        'rt': None,
                        'reads': [rs],
                        'writes': [rt]
                    }
            
            elif inst_type == 'JUMP':
                return {
                    'opcode': opcode,
                    'type': inst_type,
                    'latency': latency,
                    'rd': None,
                    'rs': None,
                    'rt': None,
                    'reads': [],
                    'writes': []
                }
        
        except (IndexError, ValueError):
            return None
        
        return None
    
    def check_forwarding(self, read_reg, current_cycle):
        """Verifica se o dado pode ser antecipado (forwarding)"""
        if read_reg not in self.register_write_cycle:
            return True  # Sem dependência
        
        write_cycle = self.register_write_cycle[read_reg]
        cycles_since_write = current_cycle - write_cycle
        
        # Adiantamento funciona a partir de WB para EX (2 estágios)
        # Se escrita foi 2 ciclos atrás ou mais, o dado está pronto em WB
        return cycles_since_write >= 2
    
    def calculate_stalls_needed(self, instruction, current_cycle):
        """Calcula quantas bolhas (NOPs) são necessárias"""
        stalls = 0
        
        for read_reg in instruction['reads']:
            if read_reg not in self.register_write_cycle:
                continue
            
            write_cycle = self.register_write_cycle[read_reg]
            cycles_since_write = current_cycle - write_cycle
            
            # Latência do LW é 2 ciclos
            # Se LW estava há 1 ciclo atrás, precisamos de 1 bolha
            if cycles_since_write < 2:
                stalls = max(stalls, 2 - cycles_since_write)
        
        return stalls
    
    def simulate_pipeline(self, instructions_str):
        """Simula pipeline e retorna total de ciclos"""
        lines = instructions_str.strip().split('\n')
        
        total_cycles = 0
        self.register_write_cycle = {}
        
        for line in lines:
            line = line.strip()
            
            # Ignorar linhas vazias e comentários
            if not line or line.startswith('#'):
                continue
            
            parsed = self.parse_instruction(line)
            if not parsed:
                continue
            
            # Calcular bolhas necessárias
            stalls_needed = self.calculate_stalls_needed(parsed, total_cycles)
            total_cycles += stalls_needed
            
            # Incrementar ciclo da instrução atual
            total_cycles += 1
            
            # Atualizar ciclo de escrita para registradores modificados
            for write_reg in parsed['writes']:
                if write_reg != 0:  # $zero não é escribível
                    # Registra ciclo em que a instrução entra no WB
                    self.register_write_cycle[write_reg] = total_cycles + parsed['latency'] - 1
        
        # Adicionar latência final da última instrução
        # O pipeline precisa esvaziar (4 ciclos após a última instrução entrar em EX)
        if self.register_write_cycle:
            total_cycles += 4
        
        return total_cycles
    
    def convert_file(self, input_file, output_file):
        """Converte arquivo MIPS para arquivo com contagem de ciclos"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            cycles = self.simulate_pipeline(content)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(str(cycles))
            
            return True
        except Exception as e:
            print(f"Erro ao converter {input_file}: {e}")
            return False


def find_usb_drive():
    """Detecta automaticamente o pendrive (D:, E:, F:, etc)"""
    import sys
    # Em Windows, procurar por drives
    if sys.platform == 'win32':
        for drive_letter in range(ord('D'), ord('Z') + 1):
            drive = f"{chr(drive_letter)}:"
            if os.path.exists(drive):
                return drive
    else:
        # Em Linux/Mac, procurar em /media ou /mnt
        for mount_point in ['/media', '/mnt']:
            if os.path.exists(mount_point):
                for item in os.listdir(mount_point):
                    path = os.path.join(mount_point, item)
                    if os.path.isdir(path):
                        return path
    return None


def process_mips_files_from_usb(usb_path=None):
    """Processa todos os arquivos TESTE-*.txt no pendrive"""
    simulator = MIPSPipelineSimulator()
    
    # Se não especificar o caminho, detectar automaticamente
    if usb_path is None:
        usb_path = find_usb_drive()
        if usb_path is None:
            print("X Erro: Nenhum pendrive detectado!")
            print("Conecte o pendrive ou especifique o caminho manualmente.")
            return
    
    # Verificar se o caminho existe
    if not os.path.exists(usb_path):
        print(f"X Erro: O caminho '{usb_path}' não existe!")
        return
    
    print(f"Procurando arquivos em: {usb_path}")
    
    # Procurar por arquivos TESTE-*.txt
    pattern = re.compile(r'TESTE-(\d+)\.txt$', re.IGNORECASE)
    files = []
    for root, dirs, filenames in os.walk(usb_path):
        for file in filenames:
            match = pattern.match(file)
            if match:
                full_path = os.path.join(root, file)
                files.append((int(match.group(1)), full_path, file))
    
    # Ordenar por número
    files.sort()
    
    if not files:
        print("X Nenhum arquivo TESTE-*.txt encontrado no pendrive!")
        return
    
    print(f"V Encontrados {len(files)} arquivo(s)\n")
    
    successful = 0
    failed = 0
    
    for numero, input_path, input_filename in files:
        # Determinar o diretório do arquivo
        input_dir = os.path.dirname(input_path)
        # Formato: TESTE-XX-RESULTADO.txt (no mesmo diretório)
        output_filename = f"TESTE-{numero:02d}-RESULTADO.txt"
        output_path = os.path.join(input_dir, output_filename)
        
        print(f"Processando: {input_filename}")
        print(f"Entrada:  {input_path}")
        print(f"Saída:    {output_path}")
        
        try:
            if simulator.convert_file(input_path, output_path):
                print(f"V Concluído com sucesso!")
                successful += 1
            else:
                print(f"X Erro ao processar!")
                failed += 1
        except Exception as e:
            print(f"X Erro: {e}")
            failed += 1
        
        print()


if __name__ == "__main__":
    import sys
    # Se passar um argumento, usar como caminho do pendrive
    if len(sys.argv) > 1:
        usb_path = sys.argv[1]
        print(f"Usando caminho especificado: {usb_path}")
        process_mips_files_from_usb(usb_path)
    else:
        # Tentar detectar automaticamente
        process_mips_files_from_usb()
