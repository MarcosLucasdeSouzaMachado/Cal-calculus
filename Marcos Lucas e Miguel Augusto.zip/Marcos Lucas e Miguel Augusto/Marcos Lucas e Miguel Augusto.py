import os
import re
from pathlib import Path


class MIPSPipelineSimulator:
    """Miguel aqui: Simula pipeline de 5 estágios MIPS com adiantamento de dados"""

    REGISTERS = {
        '$zero': 0, '$at': 1, '$v0': 2, '$v1': 3,
        '$a0': 4, '$a1': 5, '$a2': 6, '$a3': 7,
        '$t0': 8, '$t1': 9, '$t2': 10, '$t3': 11, '$t4': 12, '$t5': 13, '$t6': 14, '$t7': 15,
        '$s0': 16, '$s1': 17, '$s2': 18, '$s3': 19, '$s4': 20, '$s5': 21, '$s6': 22, '$s7': 23,
        '$t8': 24, '$t9': 25,
        '$k0': 26, '$k1': 27,
        '$gp': 28, '$sp': 29, '$fp': 30, '$ra': 31
    }

    INSTRUCTION_TYPES = {
        'add': ('R', 1), 'sub': ('R', 1), 'and': ('R', 1), 'or': ('R', 1),
        'xor': ('R', 1), 'nor': ('R', 1), 'slt': ('R', 1),
        'sll': ('R', 1), 'srl': ('R', 1), 'sra': ('R', 1),
        'mult': ('R', 3), 'div': ('R', 3),
        'mfhi': ('R', 3), 'mflo': ('R', 3),
        'mthi': ('R', 3), 'mtlo': ('R', 3),

        'addi': ('I', 1), 'andi': ('I', 1), 'ori': ('I', 1), 'xori': ('I', 1),
        'slti': ('I', 1), 'sltiu': ('I', 1),

        'lb': ('LOAD', 2),
        'lh': ('LOAD', 2),
        'lw': ('LOAD', 2),
        'lu': ('LOAD', 2),
        'lui': ('LOAD', 2),

        'sb': ('STORE', 0),
        'sh': ('STORE', 0),
        'sw': ('STORE', 0),

        'beq': ('BRANCH', 0), 'bne': ('BRANCH', 0),
        'blez': ('BRANCH', 0), 'bgtz': ('BRANCH', 0),

        'j': ('JUMP', 0), 'jal': ('JUMP', 0),
        'jr': ('JUMP', 0), 'jalr': ('JUMP', 0),
    }

    def get_register_number(self, reg):
        """Miguel aqui: Converte nome do registrador para número"""
        reg = reg.strip().lower()
        if reg in self.REGISTERS:
            return self.REGISTERS[reg]
        raise ValueError(f"Registrador inválido: {reg}")

    def parse_memory_operand(self, operand):
        """Parse operand como 'offset($register)'"""
        match = re.match(r'(-?\d+)\s*\(\s*(\$\w+)\s*\)', operand.strip())
        if match:
            offset = int(match.group(1))
            register = self.get_register_number(match.group(2))
            return offset, register
        raise ValueError(f"Formato de memória inválido: {operand}")

    def parse_instruction(self, instruction_str):
        """Parse uma instrução MIPS"""
        instruction_str = instruction_str.strip().upper()

        if '#' in instruction_str:
            instruction_str = instruction_str[:instruction_str.index('#')].strip()

        if not instruction_str:
            return None

        parts = instruction_str.split()
        opcode = parts[0].lower()

        if opcode not in self.INSTRUCTION_TYPES:
            return None

        inst_type, latency = self.INSTRUCTION_TYPES[opcode]

        try:
            if inst_type == 'R':
                if opcode in ['sll', 'srl', 'sra']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    shamt = int(parts[3])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rt],
                        'reads': [rs]
                    }
                elif opcode in ['mfhi', 'mflo']:
                    rd = self.get_register_number(parts[1].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rd],
                        'reads': []
                    }
                elif opcode in ['mthi', 'mtlo']:
                    rs = self.get_register_number(parts[1].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [],
                        'reads': [rs]
                    }
                elif opcode in ['jr', 'jalr']:
                    rs = self.get_register_number(parts[1].rstrip(','))
                    writes = []
                    if opcode == 'jalr':
                        writes = [31]
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': writes,
                        'reads': [rs]
                    }
                else:
                    rd = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    rt = self.get_register_number(parts[3].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rd],
                        'reads': [rs, rt]
                    }

            elif inst_type in ['I', 'LOAD', 'STORE']:
                if opcode in ['lw', 'lh', 'lb', 'lu']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    memory_operand = ' '.join(parts[2:])
                    offset, rs = self.parse_memory_operand(memory_operand)
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rt],
                        'reads': [rs]
                    }

                elif opcode in ['sw', 'sh', 'sb']:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    memory_operand = ' '.join(parts[2:])
                    offset, rs = self.parse_memory_operand(memory_operand)
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [],
                        'reads': [rs, rt]
                    }

                elif opcode == 'lui':
                    rt = self.get_register_number(parts[1].rstrip(','))
                    immediate = int(parts[2])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rt],
                        'reads': []
                    }

                elif opcode in ['beq', 'bne']:
                    rs = self.get_register_number(parts[1].rstrip(','))
                    rt = self.get_register_number(parts[2].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [],
                        'reads': [rs, rt]
                    }

                elif opcode in ['blez', 'bgtz']:
                    rs = self.get_register_number(parts[1].rstrip(','))
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [],
                        'reads': [rs]
                    }

                else:
                    rt = self.get_register_number(parts[1].rstrip(','))
                    rs = self.get_register_number(parts[2].rstrip(','))
                    immediate = int(parts[3])
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [rt],
                        'reads': [rs]
                    }

            elif inst_type == 'JUMP':
                if opcode == 'jal':
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [31],
                        'reads': []
                    }
                else:
                    return {
                        'opcode': opcode,
                        'type': inst_type,
                        'latency': latency,
                        'writes': [],
                        'reads': []
                    }

        except (IndexError, ValueError):
            return None

        return None

    def simulate_pipeline(self, instructions_str):
        """
        Miguel presta atenção essa parte:
        Simula pipeline de 5 estágios MIPS com adiantamento de dados.
        
        Forwarding:
        - ALU resultado: disponível em EX (C+2)
        - Load resultado: disponível em WB (C+4) <- SEM forwarding de MEM
        
        O Stall vai ser necessário se: ready_cycle >= ex_cycle
        (O valor precisa estar pronto ANTES de entrar em EX)
        """
        lines = instructions_str.strip().split('\n')

        parsed_instructions = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parsed = self.parse_instruction(line)
            if parsed:
                parsed_instructions.append(parsed)

        if not parsed_instructions:
            return 0

        reg_ready_cycle = {}
        if_cycles = []
        current_if_cycle = 0

        for inst_idx, inst in enumerate(parsed_instructions):
            max_stalls = 0

            # Verificar dependências
            for read_reg in inst['reads']:
                if read_reg == 0:
                    continue

                if read_reg in reg_ready_cycle:
                    ready_cycle = reg_ready_cycle[read_reg]
                    ex_cycle = current_if_cycle + 2

                    # Se pronto NO MESMO CICLO de EX, ainda precisa de stall
                    if ready_cycle >= ex_cycle:
                        stalls_needed = ready_cycle - ex_cycle + 1
                        max_stalls = max(max_stalls, stalls_needed)

            # Aplicar stalls
            current_if_cycle += max_stalls
            if_cycles.append(current_if_cycle)

            # Determinar quando resultado fica pronto
            inst_type = inst['type']
            
            if inst_type == 'LOAD':
                # Load: resultado em WB (ciclo C+4)
                ready_cycle = current_if_cycle + 4
            else:
                # ALU, Branch, Jump: resultado em EX (ciclo C+2)
                ready_cycle = current_if_cycle + 2

            # Registrar quando registradores ficam prontos
            for write_reg in inst['writes']:
                if write_reg != 0:
                    reg_ready_cycle[write_reg] = ready_cycle

            current_if_cycle += 1

        # Total de ciclos
        total_cycles = if_cycles[-1] + 4 + 1

        return total_cycles

    def convert_file(self, input_file, output_file):
        """Miguel aqui: Converte arquivo MIPS para arquivo com contagem de ciclos"""
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                content = f.read()

            cycles = self.simulate_pipeline(content)

            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(str(cycles))

            return True
        except Exception as e:
            print(f"Erro ao converter {input_file}: {e}")
            return False


def find_usb_drive():
    """Miguel aqui: Detecta automaticamente o pendrive"""
    import sys
    if sys.platform == 'win32':
        for drive_letter in range(ord('D'), ord('Z') + 1):
            drive = f"{chr(drive_letter)}:"
            if os.path.exists(drive):
                return drive
    else:
        for mount_point in ['/media', '/mnt']:
            if os.path.exists(mount_point):
                for item in os.listdir(mount_point):
                    path = os.path.join(mount_point, item)
                    if os.path.isdir(path):
                        return path
    return None


def process_mips_files_from_usb(usb_path=None):
    """Miguel aqui: Processa todos os arquivos TESTE-*.txt no pendrive"""
    simulator = MIPSPipelineSimulator()

    if usb_path is None:
        usb_path = find_usb_drive()
        if usb_path is None:
            print("X Erro: Nenhum pendrive detectado!")
            print("Conecte o pendrive ou especifique o caminho manualmente.")
            return

    if not os.path.exists(usb_path):
        print(f"X Erro: O caminho '{usb_path}' não existe!")
        return

    print(f"Procurando arquivos em: {usb_path}")

    pattern = re.compile(r'TESTE-(\d+)\.txt$', re.IGNORECASE)
    files = []
    for root, dirs, filenames in os.walk(usb_path):
        for file in filenames:
            match = pattern.match(file)
            if match:
                full_path = os.path.join(root, file)
                files.append((int(match.group(1)), full_path, file))

    files.sort()

    if not files:
        print("X Nenhum arquivo TESTE-*.txt encontrado no pendrive!")
        return

    print(f"V Encontrados {len(files)} arquivo(s)\n")

    successful = 0
    failed = 0

    for numero, input_path, input_filename in files:
        input_dir = os.path.dirname(input_path)
        output_filename = f"TESTE-{numero:02d}-RESULTADO.txt"
        output_path = os.path.join(input_dir, output_filename)

        print(f"Processando: {input_filename}")
        print(f"Entrada:  {input_path}")
        print(f"Saída:    {output_path}")

        try:
            if simulator.convert_file(input_path, output_path):
                print(f"V Concluído com sucesso!")
                successful += 1
            else:
                print(f"X Erro ao processar!")
                failed += 1
        except Exception as e:
            print(f"X Erro: {e}")
            failed += 1

        print()

    print(f"\n=== RESUMO ===")
    print(f"V Processados com sucesso: {successful}")
    print(f"X Falhados: {failed}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        usb_path = sys.argv[1]
        print(f"Usando caminho especificado: {usb_path}")
        process_mips_files_from_usb(usb_path)
    else:
        process_mips_files_from_usb()
